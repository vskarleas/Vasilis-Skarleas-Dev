**Version 1.5.4**

* cow_university has a problem
* crazy_cow is not completed. It needs to add the questions and add smart functionality.
* smart_cow works if it identifies correctly the operators. Otherwise, we could create seperate smart_cow files for the specific operation.

---

**Version 1.5.6**

* cow_university has a problem
* crazy_cow is not completed. It needs to add the questions and add smart functionality.
* smart_cow has been fixed. There is one error with the multiplication function right now.

---

**Version 1.7.1**

* crazy_cow completed
* cow_univeristy fixed
* smart_cow fixed

---

**Version 2.0.1**

* Part 4 programme 1 added (newcow.c)

---

**Version 2.1.0**

* Programme 2 added (newcow_2.c)
  * There is an error is line 12 and the comparison do not work. Check the comment

---

**Version 2.2.0**

* Programme newcow_2.c is now functional

---

**Version 2.3.0**

* crazy_cow.sh is now functional
* newcow_3.c is added that corresponds to the question 3 of the project file in C section (4th section). [NOT FINISHED YET]

---

**Version 3.1.0**

* newcow_3.c is now completed. There are some final modifications that needs to be done.

---

**Version 3.1.2**

* Question 4 (part c) - newcow_4.c was started.

**Version 5.0.2**

* Project is completed with Automate
* Remains to finalise the animation question and the compte rendu.

Versiomn 6.3.7

* Merges completed
* Compte rendu completed
*
